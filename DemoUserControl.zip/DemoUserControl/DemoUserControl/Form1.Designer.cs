﻿namespace DemoUserControl
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TreeNode treeNode15 = new TreeNode("Node1");
            TreeNode treeNode16 = new TreeNode("Node2");
            TreeNode treeNode17 = new TreeNode("Node3");
            TreeNode treeNode18 = new TreeNode("Node0", new TreeNode[] { treeNode15, treeNode16, treeNode17 });
            TreeNode treeNode19 = new TreeNode("Node5");
            TreeNode treeNode20 = new TreeNode("Node6");
            TreeNode treeNode21 = new TreeNode("Node7");
            TreeNode treeNode22 = new TreeNode("Node8");
            TreeNode treeNode23 = new TreeNode("Node9");
            TreeNode treeNode24 = new TreeNode("Node4", new TreeNode[] { treeNode19, treeNode20, treeNode21, treeNode22, treeNode23 });
            TreeNode treeNode25 = new TreeNode("Node10");
            TreeNode treeNode26 = new TreeNode("Node12");
            TreeNode treeNode27 = new TreeNode("Node13");
            TreeNode treeNode28 = new TreeNode("Node11", new TreeNode[] { treeNode26, treeNode27 });
            splitContainer1 = new SplitContainer();
            treeView1 = new TreeView();
            bottomBar1 = new UserControls.BottomBar();
            header1 = new UserControls.Header();
            threadsControl1 = new UserControls.ThreadsControl();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            SuspendLayout();
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(0, 0);
            splitContainer1.Margin = new Padding(3, 4, 3, 4);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.Controls.Add(button1);
            splitContainer1.Panel1.Controls.Add(treeView1);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(bottomBar1);
            splitContainer1.Panel2.Controls.Add(header1);
            splitContainer1.Panel2.Controls.Add(threadsControl1);
            splitContainer1.Size = new Size(1029, 933);
            splitContainer1.SplitterDistance = 343;
            splitContainer1.SplitterWidth = 5;
            splitContainer1.TabIndex = 0;
            // 
            // treeView1
            // 
            treeView1.Dock = DockStyle.Fill;
            treeView1.Location = new Point(0, 0);
            treeView1.Margin = new Padding(3, 4, 3, 4);
            treeView1.Name = "treeView1";
            treeNode15.Name = "Node1";
            treeNode15.Text = "Node1";
            treeNode16.Name = "Node2";
            treeNode16.Text = "Node2";
            treeNode17.Name = "Node3";
            treeNode17.Text = "Node3";
            treeNode18.Name = "Node0";
            treeNode18.Text = "Node0";
            treeNode19.Name = "Node5";
            treeNode19.Text = "Node5";
            treeNode20.Name = "Node6";
            treeNode20.Text = "Node6";
            treeNode21.Name = "Node7";
            treeNode21.Text = "Node7";
            treeNode22.Name = "Node8";
            treeNode22.Text = "Node8";
            treeNode23.Name = "Node9";
            treeNode23.Text = "Node9";
            treeNode24.Name = "Node4";
            treeNode24.Text = "Node4";
            treeNode25.Name = "Node10";
            treeNode25.Text = "Node10";
            treeNode26.Name = "Node12";
            treeNode26.Text = "Node12";
            treeNode27.Name = "Node13";
            treeNode27.Text = "Node13";
            treeNode28.Name = "Node11";
            treeNode28.Text = "Node11";
            treeView1.Nodes.AddRange(new TreeNode[] { treeNode18, treeNode24, treeNode25, treeNode28 });
            treeView1.Size = new Size(343, 933);
            treeView1.TabIndex = 0;
            // 
            // bottomBar1
            // 
            bottomBar1.Dock = DockStyle.Bottom;
            bottomBar1.Location = new Point(0, 866);
            bottomBar1.Margin = new Padding(3, 5, 3, 5);
            bottomBar1.Name = "bottomBar1";
            bottomBar1.Size = new Size(681, 67);
            bottomBar1.TabIndex = 2;
            // 
            // header1
            // 
            header1.Dock = DockStyle.Top;
            header1.Location = new Point(0, 0);
            header1.Margin = new Padding(3, 5, 3, 5);
            header1.Name = "header1";
            header1.Size = new Size(681, 53);
            header1.TabIndex = 1;
            // 
            // threadsControl1
            // 
            threadsControl1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            threadsControl1.Location = new Point(0, 53);
            threadsControl1.Margin = new Padding(3, 5, 3, 5);
            threadsControl1.Name = "threadsControl1";
            threadsControl1.Size = new Size(686, 800);
            threadsControl1.TabIndex = 0;
            // 
            // button1
            // 
            button1.Location = new Point(128, 559);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 1;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1029, 933);
            Controls.Add(splitContainer1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private SplitContainer splitContainer1;
        private TreeView treeView1;
        private UserControls.ThreadsControl threadsControl1;
        private UserControls.Header header1;
        private UserControls.BottomBar bottomBar1;
        private Button button1;
    }
}