namespace DemoUserControl
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            treeView1.ExpandAll();
            header1.setHeaderText("Material -Threads-");
            bottomBar1.OnSavePress += OnSavePress;
        }

        private void OnSavePress(object sender, EventArgs e)
        {
            MessageBox.Show("OnSavePress");
            threadsControl1.saveData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            threadsControl1.Visible = false;
            header1.setHeaderText("Material -Threads-");
        }
    }
}