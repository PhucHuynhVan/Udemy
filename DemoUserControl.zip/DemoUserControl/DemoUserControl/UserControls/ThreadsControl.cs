﻿namespace DemoUserControl.UserControls
{
    public partial class ThreadsControl : UserControl
    {
        public ThreadsControl()
        {
            InitializeComponent();
        }

        public void saveData()
        {
            MessageBox.Show("saveData");
        }
    }
}
