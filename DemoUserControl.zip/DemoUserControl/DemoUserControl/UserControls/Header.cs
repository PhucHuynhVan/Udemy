﻿namespace DemoUserControl.UserControls
{
    public partial class Header : UserControl
    {
        public Header()
        {
            InitializeComponent();
        }

        public void setHeaderText(string text)
        {
            headerLabel.Text = text;
        }
        public void setHeaderImage(Bitmap bitmap)
        {
            pictureBox1.Image = bitmap;
        }
    }
}
