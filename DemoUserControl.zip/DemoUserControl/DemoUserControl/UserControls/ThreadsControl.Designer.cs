﻿namespace DemoUserControl.UserControls
{
    partial class ThreadsControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThreadsControl));
            mainPanel = new Panel();
            groupBox1 = new GroupBox();
            textBox4 = new TextBox();
            checkBox2 = new CheckBox();
            checkBox1 = new CheckBox();
            pictureBox1 = new PictureBox();
            textBox3 = new TextBox();
            label3 = new Label();
            textBox2 = new TextBox();
            label2 = new Label();
            textBox1 = new TextBox();
            label1 = new Label();
            dataGridView1 = new DataGridView();
            ThreadCodeCol = new DataGridViewTextBoxColumn();
            ThreadNameCol = new DataGridViewTextBoxColumn();
            ThreadWindingParameterCol = new DataGridViewTextBoxColumn();
            NeedleThreadCol = new DataGridViewCheckBoxColumn();
            BobbinThreadCol = new DataGridViewCheckBoxColumn();
            PictureCol = new DataGridViewImageColumn();
            ThreadColourCol = new DataGridViewTextBoxColumn();
            CreatedByCol = new DataGridViewTextBoxColumn();
            CreatedAtCol = new DataGridViewTextBoxColumn();
            mainPanel.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // mainPanel
            // 
            mainPanel.Controls.Add(groupBox1);
            mainPanel.Controls.Add(dataGridView1);
            mainPanel.Location = new Point(0, 0);
            mainPanel.Name = "mainPanel";
            mainPanel.Size = new Size(600, 600);
            mainPanel.TabIndex = 0;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBox4);
            groupBox1.Controls.Add(checkBox2);
            groupBox1.Controls.Add(checkBox1);
            groupBox1.Controls.Add(pictureBox1);
            groupBox1.Controls.Add(textBox3);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(label1);
            groupBox1.Dock = DockStyle.Bottom;
            groupBox1.Location = new Point(0, 481);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(600, 119);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Details";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(347, 17);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(236, 23);
            textBox4.TabIndex = 9;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(480, 52);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(103, 19);
            checkBox2.TabIndex = 8;
            checkBox2.Text = "Boobin Thread";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(377, 52);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(97, 19);
            checkBox1.TabIndex = 7;
            checkBox1.Text = "Upper Thread";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(347, 49);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(24, 24);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(169, 83);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(414, 23);
            textBox3.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(10, 86);
            label3.Name = "label3";
            label3.Size = new Size(82, 15);
            label3.TabIndex = 4;
            label3.Text = "Thread Colour";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(169, 50);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(172, 23);
            textBox2.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(10, 53);
            label2.Name = "label2";
            label2.Size = new Size(150, 15);
            label2.TabIndex = 2;
            label2.Text = "Thread/Winding Parameter";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(169, 17);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(172, 23);
            textBox1.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(10, 20);
            label1.Name = "label1";
            label1.Size = new Size(43, 15);
            label1.TabIndex = 0;
            label1.Text = "Thread";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { ThreadCodeCol, ThreadNameCol, ThreadWindingParameterCol, NeedleThreadCol, BobbinThreadCol, PictureCol, ThreadColourCol, CreatedByCol, CreatedAtCol });
            dataGridView1.Location = new Point(0, 0);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(600, 475);
            dataGridView1.TabIndex = 0;
            // 
            // ThreadCodeCol
            // 
            ThreadCodeCol.HeaderText = "Thread Code";
            ThreadCodeCol.Name = "ThreadCodeCol";
            // 
            // ThreadNameCol
            // 
            ThreadNameCol.HeaderText = "Thread Name";
            ThreadNameCol.Name = "ThreadNameCol";
            // 
            // ThreadWindingParameterCol
            // 
            ThreadWindingParameterCol.HeaderText = "Thread/Winding Parameter";
            ThreadWindingParameterCol.Name = "ThreadWindingParameterCol";
            // 
            // NeedleThreadCol
            // 
            NeedleThreadCol.HeaderText = "Needle Thread";
            NeedleThreadCol.Name = "NeedleThreadCol";
            // 
            // BobbinThreadCol
            // 
            BobbinThreadCol.HeaderText = "Bobbin Thread";
            BobbinThreadCol.Name = "BobbinThreadCol";
            // 
            // PictureCol
            // 
            PictureCol.HeaderText = "";
            PictureCol.Name = "PictureCol";
            // 
            // ThreadColourCol
            // 
            ThreadColourCol.HeaderText = "Thread Colour";
            ThreadColourCol.Name = "ThreadColourCol";
            // 
            // CreatedByCol
            // 
            CreatedByCol.HeaderText = "Created By";
            CreatedByCol.Name = "CreatedByCol";
            // 
            // CreatedAtCol
            // 
            CreatedAtCol.HeaderText = "Created At";
            CreatedAtCol.Name = "CreatedAtCol";
            // 
            // ThreadsControl
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(mainPanel);
            Name = "ThreadsControl";
            Size = new Size(600, 600);
            mainPanel.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel mainPanel;
        private GroupBox groupBox1;
        private TextBox textBox2;
        private Label label2;
        private TextBox textBox1;
        private Label label1;
        private DataGridView dataGridView1;
        private TextBox textBox4;
        private CheckBox checkBox2;
        private CheckBox checkBox1;
        private PictureBox pictureBox1;
        private TextBox textBox3;
        private Label label3;
        private DataGridViewTextBoxColumn ThreadCodeCol;
        private DataGridViewTextBoxColumn ThreadNameCol;
        private DataGridViewTextBoxColumn ThreadWindingParameterCol;
        private DataGridViewCheckBoxColumn NeedleThreadCol;
        private DataGridViewCheckBoxColumn BobbinThreadCol;
        private DataGridViewImageColumn PictureCol;
        private DataGridViewTextBoxColumn ThreadColourCol;
        private DataGridViewTextBoxColumn CreatedByCol;
        private DataGridViewTextBoxColumn CreatedAtCol;
    }
}
