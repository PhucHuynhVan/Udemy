﻿namespace DemoUserControl.UserControls
{
    public partial class BottomBar : UserControl
    {


        public EventHandler OnSavePress;

        public BottomBar()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OnSavePress(this, EventArgs.Empty);
        }
    }
}
